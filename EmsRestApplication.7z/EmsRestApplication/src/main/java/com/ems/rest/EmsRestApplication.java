package com.ems.rest;
/**
 * @author Arvinder
 * Main Spring boot class.
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages={"com.ems.rest"})
public class EmsRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsRestApplication.class, args);
	}

}
