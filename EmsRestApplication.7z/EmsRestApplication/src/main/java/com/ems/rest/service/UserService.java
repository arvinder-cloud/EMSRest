package com.ems.rest.service;

/**
 * This interface defines list of method to be implemented by UserServiceImpl class.
 * @author Arvinder
 * 
 */

import java.util.List;
import com.ems.rest.model.User;

public interface UserService {

	User findById(long id);
	
	User findByName(String name);
	
	void saveUser(User user);
	
	void updateUser(User user);
	
	void deleteUserById(long id);

	List<User> findAllUsers();
	
	void deleteAllUsers();
	
	boolean isUserExist(User user);
}
