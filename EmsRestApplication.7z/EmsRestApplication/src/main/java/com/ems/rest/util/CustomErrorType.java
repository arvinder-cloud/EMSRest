package com.ems.rest.util;
/**
 * This is utility class to through custom error based on the application logic
 * @author Arvinder
 *
 */

public class CustomErrorType {
	 private String errorMessage;

	    public CustomErrorType(String errorMessage){
	        this.errorMessage = errorMessage;
	    }

	    public String getErrorMessage() {
	        return errorMessage;
	    }
}
